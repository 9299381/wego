package main

import (
	"fmt"
	"github.com/9299381/example/src/dto"
	"github.com/9299381/wego/validations"
)

func main()  {
	st := &dto.TestDto{
		Name:"admin",
		Desc: "aaaa",
	}
	valid :=validations.Validation{}
	b,_ := valid.Valid(st)
	msg := ""
	if !b {
		for _, err := range valid.Errors {
			msg += err.Key+":"+err.Message+";"
		}
	}else{
		msg ="验证ok"
	}

	fmt.Println(msg)
}
