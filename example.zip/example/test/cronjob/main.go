package main

import (
	"fmt"
	"github.com/robfig/cron/v3"
	"log"
	"time"
)

func main() {
	log.Println("Starting...")
	nyc, _ := time.LoadLocation("Asia/Shanghai")
	var c = cron.New(cron.WithSeconds(), cron.WithLocation(nyc))
	id1, _ := c.AddFunc("*/2 * * * * *", func() {
		log.Println("schedule every 2 seconds ...")
	})
	log.Println("schedule EntryID: " + fmt.Sprintf("%d", id1))

	id2, _ := c.AddFunc("*/5 * * * * *", func() {
		log.Println("schedule every 5 seconds ...")
	})
	log.Println("schedule EntryID: " + fmt.Sprintf("%d", id2))

	c.Start()
	select {}
}