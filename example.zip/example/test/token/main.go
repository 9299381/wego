package main

import (
	"fmt"
	"github.com/9299381/wego/tools/jwt"
)

func main()  {
	token :=jwt.NewToken().
		SetId("123").
		SetName("aaa").
		SetRole("user").
		GetToken()

	fmt.Println(token)

	t := "eyJpZCI6IjExOTI1MDc1ODQ3NDYyMDU5NTIiLCJuYW1lIjoiMTgzKioqKjA4ODMiLCJyb2xlIjoiUDEzMDEiLCJpYXQiOjE1NTQ4NjU1NjksImV4cCI6MTU1NzQ1NzU2OX0=.533ea26174741cdd7cc6badac22b21c5"
	claim, err := jwt.NewToken().VerifyToken(t)
	if err!=nil{
		fmt.Println(err)
	}else{
		fmt.Println(claim)
	}
}
