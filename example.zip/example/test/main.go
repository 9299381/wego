package main

import (
	"flag"
	"fmt"
	"github.com/9299381/wego/constants"
)

func main()  {
	//flag.Parse()

	demo := constants.Key
	demo = "hello"
	fmt.Println(demo)
	fmt.Println(constants.Key)
	flag.PrintDefaults()
}