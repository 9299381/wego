package main

import (
	"encoding/json"
	"github.com/9299381/wego/contracts"
	"github.com/gorilla/websocket"
	"log"
	"net/url"
	"os"
	"os/signal"
	"time"
)

func main()  {

	//testOne()
	testLong()


}
func testOne()  {
	log.SetFlags(0)
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)
	u := url.URL{Scheme: "ws", Host: "localhost:8342", Path: "/ws"}
	log.Printf("connecting to %s", u.String())
	c, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		log.Fatal("dial:", err)
	}
	defer c.Close()
	done := make(chan struct{})

	go func() {
		defer close(done)
		for {
			_, message, err := c.ReadMessage()
			if err != nil {
				log.Println("read:", err)
				return
			}
			log.Printf("recv: %s", message)
		}
	}()

	args := make(map[string]interface{})
	args["client"] = "websocket"
	args["aa"] = "wet"
	payLoad := contracts.Payload{
		Class:"websocket_test",
		Args:args,
	}
	jsonPayload ,errJson := json.Marshal(payLoad)
	if errJson != nil{
		panic(errJson)
	}

	errWrite := c.WriteMessage(websocket.TextMessage, jsonPayload)
	if errWrite != nil {
		log.Println("write:", err)
		return
	}

}

func testLong()  {
	log.SetFlags(0)
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)
	u := url.URL{Scheme: "ws", Host: "localhost:8342", Path: "/ws"}
	log.Printf("connecting to %s", u.String())
	c, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		log.Fatal("dial:", err)
	}
	defer c.Close()
	done := make(chan struct{})

	go func() {
		defer close(done)
		for {
			_, message, err := c.ReadMessage()
			if err != nil {
				log.Println("read:", err)
				return
			}
			log.Printf("client_recv: %s", message)
		}
	}()

	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-done:
			return
		case <-ticker.C:

			args := make(map[string]interface{})
			args["client"] = "websocket"
			args["aa"] = "wet"
			payLoad := contracts.Payload{
				Class:"websocket_test",
				Args:args,
			}
			jsonPayload ,errJson := json.Marshal(payLoad)
			if errJson != nil{
				panic(errJson)
			}

			err := c.WriteMessage(websocket.TextMessage, jsonPayload)
			if err != nil {
				log.Println("write:", err)
				return
			}
		case <-interrupt:
			log.Println("interrupt")

			// Cleanly close the connection by sending a close message and then
			// waiting (with timeout) for the server to close the connection.
			err := c.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
			if err != nil {
				log.Println("write close:", err)
				return
			}
			select {
			case <-done:
			case <-time.After(time.Second):
			}
			return
		}
	}

}
