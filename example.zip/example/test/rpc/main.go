package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/9299381/wego/clients"
	"github.com/9299381/wego/servers/transports/protobuf"
	"github.com/golang/protobuf/proto"
	"google.golang.org/grpc"
	"log"
)

func main() {

	testGrpcClient()

}

func testProto() {
	param := make(map[string]interface{})
	param["service"] = "TestService"
	param["method"] = "handle"
	json, _ := json.Marshal(param)

	msg := &protobuf.Request{
		Id:    "11111111",
		Param: string(json),
	}

	buffer,_ := proto.Marshal(msg)
	fmt.Println(string(buffer))


}


func testRpcClient()  {
	serviceAddress := "127.0.0.1:9341"

	// Set up a connection to the server.
	conn, err := grpc.Dial(serviceAddress, grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()


	param := make(map[string]interface{})
	param["service"] = "TestService"
	param["method"] = "handle"
	jsonParam, _ := json.Marshal(param)
	in := &protobuf.Request{
		Id:    "11111111",
		Param: string(jsonParam),
	}


	client := protobuf.NewServiceClient(conn)
	response, err:=client.Handle(context.Background(),in)
	if err != nil {
		log.Fatalf("error response: %v", err)
	}
	log.Println(response.Data)


}
func testRpcClient1()  {

	serviceAddress := "127.0.0.1:9341"

	// Set up a connection to the server.
	conn, err := grpc.Dial(serviceAddress, grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	param := make(map[string]interface{})
	param["service"] = "TestService"
	param["method"] = "handle"
	jsonParam, _ := json.Marshal(param)
	in := &protobuf.Request{
		Id:    "11111111",
		Param: string(jsonParam),
	}


	out := new(protobuf.Response)
	_ = conn.Invoke(context.Background(), "/protobuf.Two/Handle", in, out)

	log.Println(out.Data)
}

func testGrpcClient()  {
	param := make(map[string]interface{})
	param["aaa"] = "bbb"
	param["ccc"] = "ddd"
	resp := clients.NewGrpcClient("Two",param)
	fmt.Println(resp.Data)

}
