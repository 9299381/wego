package main

import (
	"fmt"
	"github.com/9299381/wego"
	"github.com/9299381/wego/providers"
	"reflect"
)

type Demo struct {
	Name string
	Age int
}

func testRef()  {
	demo := &Demo{
		Name:"123123",
		Age:123,
	}
	//relType := elem.Type()
	//f := relType.NumField()
	vf :=getByKey(demo,"Name")
	if vf != nil{
		fmt.Println(vf.(string))
	}
	fmt.Println(vf)
}
func main()  {
	//testRef()
	wego.Provider(&providers.BootStrap{})
	v := wego.Config("cache")
	fmt.Println(v)

}

func getByKey(data interface{}, key string)  interface{}{
	rdata := reflect.ValueOf(data)
	ret := rdata.Elem().FieldByName(key)
	if ret.IsValid(){
		return ret.Interface()
	} else {
		return nil
	}
}